﻿Get-KeysAndValuesFromJsonFile -paramToSerach DOTcom-uat-rg
