﻿
param(
        [Parameter()]
        [double]$Number1,
        [Parameter()]
        [double]$Number2
    )

       $result=$Number1+$Number2;
       write-host("Result after Addition is "+$result);



