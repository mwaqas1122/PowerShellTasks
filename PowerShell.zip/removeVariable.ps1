﻿New-Variable waqas "124"
