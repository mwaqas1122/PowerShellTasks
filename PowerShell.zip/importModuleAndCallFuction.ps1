﻿Import-Module C:\PowerShell\mymodules\getinfo.psm1
Get-Info -ComputerName localhost